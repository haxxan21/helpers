<?php
    
    require_once 'Connection.php';

    class FindUser{
    
        public static $array; 

        public static function index($fileName){
            self::$array = array(); 
            //reading xlsx file contents
            if ($xlsx = SimpleXLSX::parse($fileName)) {
                $data = $xlsx->rows();
                // iterating excel rows
                for ($i = 0; $i < count($data); $i++) {
                    // get even indexes 
                    if ($i % 2 == 0) {
                        $mail =  $data[$i][0];
                        $query = "SELECT user_id, email FROM `engine4_users` where email = " . "'$mail'";
                        $result = Connection::index()->query($query);
                        $row = mysqli_fetch_assoc($result);
                        if (!$row) {
                            // print user emails when record not found
                            echo "not found: " . $mail;
                            echo '</br>';
                        } else {
                            // create array of found users 
                            array_push(self::$array, $row);
                        }
                    }
                }
                // returning response
                return self::$array;
        }else{
                echo SimpleXLSX::parseError();
        }
    }
}

?>