<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', true);

require_once 'SimpleXLSX.php';
require_once 'Connection.php';
require_once 'FindUser.php';
$connection = Connection::index();

$data = FindUser::index('VetProfessionalPremiumMonthly.xlsx');

echo '<pre>';

print_r(count($data));
echo '</br>';
// halt further execution, comment exit; to update table
exit;
// updating user levels
for ($i = 0; $i < count($data); $i++) {
	$id = $data[$i]['user_id'];
	$query = "UPDATE `engine4_users` SET level_id = 8 where user_id = " . "'$id'";
	$result = $connection->query($query);
	if (!$result) {
		echo 'cannot update' . $data[$i]['email'];
	} else {
		echo 'success' . $id;
		echo '</br>';
	}
}
echo '<pre>';
