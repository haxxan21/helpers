<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', true);

require_once 'SimpleXLSX.php';
require_once 'connection.php';
require_once 'FindUser.php';
$connection = Connection::index();

$data = FindUser::index('PetOwner.xlsx');

echo '<pre>';

print_r(count($data));
echo '</br>';
// halt further execution, comment exit; to update table
exit;
// updating user Networks
for ($i = 0; $i < count($rows); $i++) {
    $id = $rows[$i]['user_id'];
    $query = "DELETE FROM `engine4_network_membership` where user_id = " . "'$id'";
    $result = $connection->query($query);
    $query = "INSERT INTO `engine4_network_membership` Values(6," . $id . ", 1, 1, 1)";
    $result = $connection->query($query);
}

echo '<pre>';
