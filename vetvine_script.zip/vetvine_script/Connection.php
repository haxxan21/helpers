<?php

class Connection
{

    public static $conn;

    public static function index()
    {
        self::$conn = new mysqli('localhost', 'root', '', 'vetvine_prod');
        if (self::$conn->connect_errno) {
            die('connection failed' . self::$conn->connect_error);
        } else {
            return self::$conn;
        }
    }
}
