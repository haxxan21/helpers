<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors', true);

require_once 'SimpleXLSX.php';
require_once 'Connection.php';
require_once 'FindUser.php';
$connection = Connection::index();

$data = FindUser::index('TrainerAnimalBehaviourConsultant.xlsx');
echo '<pre>';

print_r(count($data));
echo '</br>'; 
// halt further execution, comment exit; to update table
exit;
// updating user professions
for ($i = 0; $i < count($rows); $i++) {
	$id = $rows[$i]['user_id'];
	$query = "UPDATE `engine4_user_fields_values` SET value = 3255 where item_id = " . "'$id'" . " AND field_id = 65 ";
	$result = $connection->query($query);
	if (!$result) {
		echo 'cannot update' . $rows[$i]['email'];
	} else {
		echo $i . '- success ' . $rows[$i]['email'];
		echo '</br>';
	}
}

echo '<pre>';
